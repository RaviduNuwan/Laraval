<!DOCTYPE html>
<html>
<head><title>Admin Dashboard</title></head>
<body>
    <h2>Welcome to Admin Dashboard</h2>
</body>
</html>