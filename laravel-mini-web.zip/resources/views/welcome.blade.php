<!DOCTYPE html>
<html>
<head><title>Home Page</title></head>
<body>
    <h1>Welcome to the Laravel Mini Web Page</h1>
    <a href="{{ route('admin.login') }}">Admin Login</a>
</body>
</html>